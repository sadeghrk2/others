# How to use Storm with Learning engine

It is important to add the following flags, otherwise things may go wrong:
`--buildfull` build choice labels, state valuations and all that stuff
`--engine learning` choose our engine
`--no-simplify` make sure that the prism-model is not simplified (I don't actually know what it does, but leaving this option out, makes the whole thing not work)

There are two possible ways to evaluate a DT:
* Set the flag `--evaluationMethod statistical` or `--evaluationMethod full` 
* full (not implemented yet)
* statistical, option two flags `--smcruns X` X is number of simulations, `--smcmaxsteps Y` Y is the number of maximum steps per simulation

To make things faster, set `--reachable`. This will only use reachable states and their actions to learn the DT from. We could play around with that a little.

You can
* load a Decision-tree in dot- or json-format (the dot-format has to follow certain restrictions). Use `--decisiontree FILENAME` for this
* load a data-file and learn a DT on that. Use `--datafile FILENAME`. Make sure that it is a csv-file, that only contains the pure data in rows, and the action as last column. No headers and nothing, if you want to use MLPack. Dtcontrol can work with its usual headers (#NON-Permissive ...), but they don't have to be there.
* learn a DT from other models. There are two options for that: by changing the parameter of the model or by giving a list of model-files to learn from.
* learn a DT on a huge model with DTStrat without having small models to learn from

## Specify the parameter and the possible parameters to learn from
* `--learnParameter X,Y,Z`: specify the parameter-values that you want to learn from (e.g. `--learnParameter 2,3,4`)
* `--paramName K`: specify the parameter name (e.g. `K`) (several parameters is not yet possible)
* `--dtLearning METHOD`: specify how you want to learn the DT (i.e. `mlpack`,`dtcontrol` or `sklearn`, where the latter is not yet implemented)

Dont forget to set the constants for the model that you want to verify on (e.g. for zeroconf `--constants reset=false,N=20,K=10`)

## Specify files to learn from
* `--childTasks SOMETHING` where SOMETHING has the following shape CHILDRENFILE1#PROPERTY1%CHILDRENFILE2#PROPRETY2% ...
That is, two tasks for a smaller file are seperated by %. The file and the Property are seperated by #. Make sure that these symbols don't appear in your property of filename.

## Directly learn on a huge model without learning on small ones first
If the model is huge, and there is no parameter to make it smaller, use DTStrat to learn a DT while exploring with BRTDP.
* Default, if no parameter or child-task is set.
* specify `--updateSteps X` where X is the number of simulations before you learn a new DT for heuristic

## Example commands:
* Load a DT and run it: TBD
* Load a datafile and run it: `storm --prism working_models/zeroconf.prism --prop working_models/zeroconf.props --buildfull --constants K=6,N=20,reset=false --engine learning --datafile zeroconf_2_3_4.csv --decisiontree dtcontrol --evaluationMethod statistical`
* Run on zeroconf for some smaller parameters `storm --prism working_models/zeroconf.prism --prop working_models/zeroconf.props --buildfull --engine learning --learnParameter 2,3,4 --paramName K --no-simplify --dtLearning mlpack --evaluationMethod statistical --smcruns 50000 --smcmaxsteps 10000 --constants reset=false,N=20,K=10 --reachable`
* Run on philosophers: `storm --prism working_models/philosophers.5.prism --prop working_models/philosophers.5.props --buildfull --engine learning --no-simplify --dtLearning mlpack --evaluationMethod statistical --smcruns 50000 --smcmaxsteps 10000 --reachable --childTasks "working_models/philosophers.4.prism#Pmax=? [ F (((p1>=8)&(p1<=9))|((p2>=8)&(p2<=9))|((p3>=8)&(p3<=9))|((p4>=8)&(p4<=9))) ]%working_models/philosophers.3.prism#Pmax=? [ F (((p1>=8)&(p1<=9))|((p2>=8)&(p2<=9))|((p3>=8)&(p3<=9))) ]"`
* Run with DTStrat: `storm --prism working_models/zeroconf.prism --prop working_models/zeroconf.props --buildstateval --engine learning --no-simplify --dtLearning mlpack --evaluationMethod statistical --smcruns 50000 --smcmaxsteps 10000 --constants reset=false,N=20,K=6 --reachable --updateSteps 5`

## How to use Storm with DTStrat 

It can be installed exactly as Storm itself (see https://www.stormchecker.org/documentation/obtain-storm/build.html after installing its dependencies https://www.stormchecker.org/documentation/obtain-storm/dependencies.html).
That is 
`mkdir build`
`cd build`
`cmake ..`
`make`

Models can be obtained e.g. from https://qcomp.org/benchmarks/index.html

I tested it with the philosophers, zeroconf and firewire and storm could run on all of them (if DTStrat works on all of them is still an open question). You need to download the prism/jani-file and the properties (usually a .props-file). So you have a MODEL.prism and a PROPERTY.props file somewhere.

Storm with DTStrat is now called as:

`storm --prism MODEL.prism --prop PROPERTY.props --engine expl --dtstrat`

`--engine expl`: is needed to use the BRTDP exploration algorithm

`--dtstrat`: sets the use of a DTStrat

sometimes you need the constants (depending on which model you use) e.g.
`--constants N=1000,K=1,reset=true,deadline=10`

To define the learning parameters:

`--learnConfig`: define how to learn a configuration, can currently be either 'non' (learn nothing at all), 'basic' (update every X steps), 'genetic' (learn using some genetic learning approach)

`--heuristic`: define which heuristic to learn, can be either 'non' (nothing), 'dtcontrol' (one tree for everything), 'module' (one tree per module)

`--explEpsilon`: define how much to explore and how much to follow BRTDP (default is 0 = only follow heurstic, never use BRTDP)

`--updateSteps`: define after how many steps an update/learning-step should be performed (default is -1 = never)

`--onlyReachable`: determines whether to use only reachable states for the strategy, i.e. only exports reachable states and their actions for the learning

`--moduleHeuristic`: only necessary if 'learnConfig' is 'basic' and 'heuristic' is 'module'; defines the heuristic for the module (which should go next); can be either 'ordering' (just use 0 1 2 3...), 'orderingrandom' (generates a random ordering), 'orderingtree' (orders the modules corresponding to the size of their trees - bigger is better) or 'decisiontree' (learn a tree to define which module to play); default is 'ordering'


## How to run with sklearn (deprecated since commit e10db440)
storm --prism working_models/philosophers.3.prism --prop working_models/philosophers.3.props --engine expl --dtstrat2 --DecisionTreeType multiSklearn --updatesteps 5 --printOnlyRelevant --printVariableInfo --printModules --moduleChoice treeSize
moduleChoice can also be smallest or random


This is a copy of storm used to change BRTDP!


## Hyperparameter for DTStrat (deprecated since commit e10db440)
Additional hyperparameter that can be set (flag + default parameter):

`--epsilon 0.5`: in the usual RL-Value-Iteration you switch between exploring randomly the environment and following your already existing guidance. That is done by drawing a random number between 0 and 1. If this number is smaller than epsilon, we randomly explore (in this case, we follow BRTDP), if it is greater, we follow the decision tree

`--alpha 0.8`: learning rate as discussed (only used if no trueq is set)

`--gamma 1.0`: discount factor as discussed (should not be changed and is default 1)

`--histmin 500`: how often a node has to be visited at least to be split

`--updatesteps 0`: after how many simulations the DT is updated (I just introduced it, because it takes a loooong time to run if the DT is really updated after each simulation). 

`--learningQvalues`: if set the 'wrong' Q-values are calculated (as discussed in our meeting on 11.11.), by default it is off

`--splitdecision tstatistic`: this can change the function for calculating the split. It is specified as a string and has to be adapted in updateDt.h::get_split()

`--batchupdate`: this flag can be set to activate real batch learning, i.e. a certain number of simulations is run (specified in updatesteps) and all steps are remembered and used in the update of the decision tree.

`--deleteTree`: this flag can be set to delete the tree before learning it completely new

`--runparallel`: this flag should be set if one wants to get the results of a run printed in a useful manner in the command window, to catch them and write them into a file.

`--nodot`: prevents the printing of the decision tree as a dot-file after the run (makes sense, if it has more than 50 nodes)

`--printdtcontrol`: prints the decision tree of dtcontrol in a json-file "DtControl_DT".json (useful for debugging)

## Hyperparameter for DTStrat2 (aka Storm+Dtcontrol
To invoke dtcontrol to create a decision tree, the flag `--dtstrat2` hast to be set.
Additionally, one hast to set the `--updatesteps 2` to a value >=2.

## Debugging information
`--dtdebug` prints after each step of the model checking the so far explored graph of the model into the file 'storm_graph.txt' in the dot-format.


# Original STORM stuff

------------------------------------------

[![Build Status](https://travis-ci.org/moves-rwth/storm.svg?branch=master)](https://travis-ci.org/moves-rwth/storm)
=======
Storm - A Modern Probabilistic Model Checker
============================================

[![Build Status](https://github.com/moves-rwth/storm/workflows/Build%20Test/badge.svg)](https://github.com/moves-rwth/storm/actions)
[![GitHub release](https://img.shields.io/github/release/moves-rwth/storm.svg)](https://github.com/moves-rwth/storm/releases/)
[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.1181896.svg)](https://doi.org/10.5281/zenodo.1181896)


For more instructions, check out the documentation found in [Getting Started](http://www.stormchecker.org/getting-started.html).


Benchmarks
----------------------------

Example input files for Storm can be obtained from  
https://github.com/moves-rwth/storm-examples.

Various Benchmarks together with example invocations of Storm can be found at the [Quantitative Verification Benchmark Set (QVBS)](http://qcomp.org/benchmarks).

Further examples and benchmarks can be found in the following repositories:

* **Prism files** (DTMC, MDP, CTMC):  
http://www.prismmodelchecker.org/benchmarks
* **Jani files** (DTMC, MDP, CTMC, MA):  
http://jani-spec.org
* **GSPN**s:  
(private, contact: sebastian.junges@cs.rwth-aachen.de)
* **DFT**s:  
https://github.com/moves-rwth/dft-examples
* **PGCL**:  
(private, contact: sebastian.junges@cs.rwth-aachen.de)


Authors
-----------------------------
Storm has been developed at RWTH Aachen University.

###### Principal developers
* Christian Hensel
* Sebastian Junges
* Joost-Pieter Katoen
* Tim Quatmann
* Matthias Volk

###### Developers (lexicographical order)
* Jana Berger
* Alexander Bork
* David Korzeniewski
* Jip Spel

###### Contributors (lexicographical order)
* Daniel Basgöze
* Dimitri Bohlender
* Harold Bruintjes
* Michael Deutschen
* Linus Heck
* Thomas Heinemann
* Thomas Henn
* Tom Janson
* Jan Karuc
* Joachim Klein
* Gereon Kremer
* Sascha Vincent Kurowski
* Hannah Mertens
* Stefan Pranger
* Svenja Stein
* Manuel Sascha Weiand
* Lukas Westhofen
