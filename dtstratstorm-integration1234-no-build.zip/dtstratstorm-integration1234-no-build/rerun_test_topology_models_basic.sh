#! /bin/bash

time=3600s

for i in 2 3 4 5 6 7 8; do    
    if timeout $time storm --prism topology_models/flock.$i.prism --prop topology_models/flock.$i.props --engine expl --dtstrat --learnConfig basic  --onlyReachable --updateSteps 5 --heuristic module;
        then
        for k in 1 2 3 4 5 --heuristic module; do
            timeout $time storm --prism topology_models/flock.$i.prism --prop topology_models/flock.$i.props --engine expl --dtstrat --learnConfig basic  --onlyReachable --updateSteps 5 --heuristic module;
        done
    fi
    if timeout $time storm --prism topology_models/ring.$i.prism --prop topology_models/flock.$i.props --engine expl --dtstrat --learnConfig basic  --onlyReachable --updateSteps 5 --heuristic module;
        then
        for k in 1 2 3 4 5 --heuristic module; do
            timeout $time storm --prism topology_models/ring.$i.prism --prop topology_models/flock.$i.props --engine expl --dtstrat --learnConfig basic  --onlyReachable --updateSteps 5 --heuristic module;
        done
    fi
    if timeout $time storm --prism topology_models/half-flock.$i.prism --prop topology_models/flock.$i.props --engine expl --dtstrat --learnConfig basic  --onlyReachable --updateSteps 5 --heuristic module;
        then
        for k in 1 2 3 4 5 --heuristic module; do
            timeout $time storm --prism topology_models/half-flock.$i.prism --prop topology_models/flock.$i.props --engine expl --dtstrat --learnConfig basic  --onlyReachable --updateSteps 5 --heuristic module;
        done
    fi
    if timeout $time storm --prism topology_models/king-flock.$i.prism --prop topology_models/flock.$i.props --engine expl --dtstrat --learnConfig basic  --onlyReachable --updateSteps 5 --heuristic module;
        then
        for k in 1 2 3 4 5 --heuristic module; do
            timeout $time storm --prism topology_models/king-flock.$i.prism --prop topology_models/flock.$i.props --engine expl --dtstrat --learnConfig basic  --onlyReachable --updateSteps 5 --heuristic module;
        done
    fi
    if timeout $time storm --prism topology_models/king-ring.$i.prism --prop topology_models/flock.$i.props --engine expl --dtstrat --learnConfig basic  --onlyReachable --updateSteps 5 --heuristic module;
        then
        for k in 1 2 3 4 5 --heuristic module; do
            timeout $time storm --prism topology_models/king-ring.$i.prism --prop topology_models/flock.$i.props --engine expl --dtstrat --learnConfig basic  --onlyReachable --updateSteps 5 --heuristic module;
        done
    fi
    if timeout $time storm --prism topology_models/independent.$i.prism --prop topology_models/flock.$i.props --engine expl --dtstrat --learnConfig basic  --onlyReachable --updateSteps 5 --heuristic module;
        then
        for k in 1 2 3 4 5 --heuristic module; do
            timeout $time storm --prism topology_models/independent.$i.prism --prop topology_models/flock.$i.props --engine expl --dtstrat --learnConfig basic  --onlyReachable --updateSteps 5 --heuristic module;
        done
    fi
    
done
