from sklearn import tree
import pandas as pd
import sys

def train_decision_tree(features, labels):
    clf = tree.DecisionTreeClassifier(criterion="gini")
    # clf = tree.DecisionTreeClassifier(criterion="entropy")
    clf = clf.fit(features, labels)
    #for index, row in features.iterrows():
    #    print(row, clf.predict([row]))
    # skljson.to_json(clf, "test.json")
    #print("split criterion:", clf.criterion)
    # clf = clf.fit(features[:13], labels[:13])
    # tree.plot_tree(clf)
    # tree.export_graphviz(clf, out_file="tree.dot")
    #print("accuracy:", clf.score(features, labels)*100, "percent")

    # dot_data = tree.export_graphviz(clf, out_file="tree.dot")
    # graph = graphviz.Source(dot_data)
    # graph.render("tree.pdf")
    # text_representation = tree.export_text(clf, max_depth=500)
    # with open("decistion_tree.log", "w") as fout:
    #    fout.write(text_representation)
    return clf

def convert(filename,tree,actions,feature_names_complete,feature_namespart):
    lines = []
    lines.append("digraph {\n")
    left = tree.tree_.children_left
    right = tree.tree_.children_right
    threshold = tree.tree_.threshold
    features = [feature_namespart[max(0,i)] for i in tree.tree_.feature]
    value = tree.tree_.value
    lines = recurse(lines, left, right, threshold, features, 0, 1,value,tree.classes_,feature_names_complete)
    lines.append("}")
    with open(filename,"w+") as f:
        f.writelines(lines)
    
def recurse(lines, left, right, threshold, features, node, tabs,value,classnames,feature_names1):
    #print("Node",node,": ",feature_names.index(features[node]),threshold[node])
    if threshold[node] != -2:
        #lines.append(f"{node} [label=\"x_{feature_names1.index(features[node])} <= {threshold[node]}\"];\n")
        lines.append(f"{node} [label=\"x_{feature_names1.index(features[node])} <= {threshold[node]}\"];\n")
        if left[node] != -1:
            lines.append(f"{node} -> {left[node]} [label=\"true\"];\n")
            lines = recurse(lines, left, right, threshold, features, left[node], tabs,value,classnames,feature_names1)
        if right[node] != -1:
            lines.append(f"{node} -> {right[node]} [label=\"false\"];\n")
            lines = recurse(lines, left, right, threshold, features, right[node], tabs,value,classnames,feature_names1)
    else:
        lines.append(f"{node} [label=\"actions[0] = {classnames[value[node].argmax()]},\"];\n")
        #print("leaf node:",int(classnames[value[node].argmax()]))
    return lines

if __name__ == '__main__':
    df = pd.read_csv(sys.argv[1], header=None, delimiter=",")
    variant = 0
    if len(sys.argv)>2:
        if sys.argv[2] == "statesPerModule":
            variant = 1
    #filename = "working_models/philosophers.3.prism1636987550.csv"
    #df = pd.read_csv(filename, header=None, delimiter=",")
    num_sv = int(df[0][0].split(" ")[-2])
    num_act = int(df[0][0].split(' ')[-1])
    df = df.drop([0])
    present_modules = [int(i) for i in df[num_sv].unique()]
    #print(df)
    #print(present_modules)
    feature_names = ["x_"+str(i) for i in range(int(num_sv/2))]
    for val in present_modules:
        sv_for_val = df.loc[1]
        if variant == 1:
            good_vals = []
            for k in range(0,num_sv,2):
                testasg = int(sv_for_val[k])
                if testasg == val or testasg == -1:
                    good_vals.append(k+1)
        else:
            good_vals = list(range(1,num_sv+1,2))
        df_val = df.loc[df[num_sv] == val]
        if variant == 1:
            feature_names1 = ["x_"+str(i) for i in range(len(good_vals))]
        else:
            feature_names1 = ["x_"+str(int((i-1)/2)) for i in good_vals]
        #print(df_val)
        #stateValuations = df_val[list(range(1,num_sv,2))]
        stateValuations = df_val[good_vals]
        actions = [int(i) for i in df_val[num_sv+1]]
        #print("stateVals",stateValuations)
        #print("actions",actions)
        print("-------- GET DT FOR MODULE",val,"-------")
        try:
            #print(stateValuations.shape)
            dt_classifier = train_decision_tree(stateValuations, actions)
            modelName = sys.argv[1][:-4]
            outfile = modelName + "_moduleDT_"+str(int(val))+".dot"
            #tree.export_graphviz(dt_classifier,out_file=outfile,feature_names=feature_names,label="none",impurity=False)
            convert(outfile,dt_classifier,actions,feature_names,feature_names1)
        except Exception as e:
            print(e)
        #print("____Done with DT________")
    print("-------- GET MODULE DT -------")
    good_vals = list(range(1,num_sv+1,2))
    stateValuations = df[good_vals]
    modules = [int(i) for i in df[num_sv]]
    dt_classifier = train_decision_tree(stateValuations, modules)
    modelName = sys.argv[1][:-4]
    outfile = modelName + "_moduleDT.dot"
    feature_names1 = ["x_"+str(int((i-1)/2)) for i in good_vals]
    #tree.export_graphviz(dt_classifier,out_file=outfile,feature_names=feature_names,label="none",impurity=False)
    convert(outfile,dt_classifier,modules,feature_names,feature_names1)
